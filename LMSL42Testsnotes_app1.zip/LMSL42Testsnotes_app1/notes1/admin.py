from django.contrib import admin
from .models import Category, Note

admin.site.register(Category)
admin.site.register(Note)
# Register your models here.
