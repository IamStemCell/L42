from django.test import TestCase

# Create your tests here.


from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from .models import Note, Category

class NoteTestCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpassword')
        self.category = Category.objects.create(title='Test Category')
        self.note = Note.objects.create(
            title='Test Note',
            text='Test text',
            reminder='2023-06-26',
            category=self.category,
        )

    def test_create_note_view(self):
        url = reverse('create_note')
        form_data = {
            'title': 'New Note',
            'text': 'New text',
            'reminder': '2023-06-27',
            'category': 'New Category',
        }
        response = self.client.post(url, data=form_data)
        self.assertEqual(response.status_code, 302)  # Redirects to note detail page
        created_note = Note.objects.latest('id')
        self.assertEqual(created_note.title, 'New Note')
        self.assertEqual(created_note.text, 'New text')
        self.assertEqual(created_note.reminder, '2023-06-27')
        self.assertEqual(created_note.category.title, 'New Category')

    def test_note_detail_view(self):
        url = reverse('note_detail', args=[self.note.id])
        form_data = {
            'title': 'Updated Note',
            'text': 'Updated text',
            'reminder': '2023-06-28',
            'category': 'Updated Category',
        }
        response = self.client.post(url, data=form_data)
        self.assertEqual(response.status_code, 302)  # Redirects to note detail page
        updated_note = Note.objects.get(id=self.note.id)
        self.assertEqual(updated_note.title, 'Updated Note')
        self.assertEqual(updated_note.text, 'Updated text')
        self.assertEqual(updated_note.reminder, '2023-06-28')
        self.assertEqual(updated_note.category.title, 'Updated Category')




#Terminal: python3 manage.py test notes1
#FAIL: test_create_note_view (notes1.tests.NoteTestCase)
#        FAIL: test_create_note_view (notes1.tests.NoteTestCase)
#----------------------------------------------------------------------
#Traceback (most recent call last):
#  File "/Users/LMSL42Testsnotes_app1/notes1/tests.py", line 35, in test_create_note_view
#    self.assertEqual(created_note.reminder, '2023-06-27')
#AssertionError: datetime.datetime(2023, 6, 27, 0, 0, tzinfo=<UTC>) != '2023-06-27'

#======================================================================
#FAIL: test_note_detail_view (notes1.tests.NoteTestCase)
#----------------------------------------------------------------------
#Traceback (most recent call last):
#  File "/UsersMSL42Testsnotes_app1/notes1/tests.py", line 51, in test_note_detail_view
#    self.assertEqual(updated_note.reminder, '2023-06-28')
#AssertionError: datetime.datetime(2023, 6, 28, 0, 0, tzinfo=<UTC>) != '2023-06-28'

#----------------------------------------------------------------------
#Ran 2 tests in 0.867s

#FAILED (failures=2)
#Destroying test database for alias 'default'...
